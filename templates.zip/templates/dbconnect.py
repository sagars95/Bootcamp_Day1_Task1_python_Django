#!/usr/bin/python
from django.shortcuts import render

from django.shortcuts import render, redirect

from django.contrib.auth import login, authenticate

from forms import SignUpForm
import TestProj.polls.migrations SignUpForm
import TestProj.core.forms

import psycopg2

conn = psycopg2.connect(database = "postgres", user = "postgres", password = "123", host = "localhost", port = "5432")
print ("Opened database successfully");

form = SignUpForm();
        fname = form.cleaned_data.get('first_name')
        lastname = form.cleaned_data.get('last_name')
        email = form.cleaned_data.get('email')
        pnumber = form.cleaned_data.get('phone_number')
        country = form.cleaned_data.get('country')
        c_city = form.cleaned_data.get('current_city')


cur = conn.cursor()

cur.execute("INSERT INTO emp (fname,lname,email,pnumber,country,current_city)\
      VALUES (?,?,?,?,?,?,?)");

form.setString(1,fname);
form.setString(2,lastname);
form.setString(3,email);
form.setString(4,pnumber);
form.setString(5,country);
form.setString(6,c_city);

conn.commit()
print ("Records created successfully");
conn.close()