from django.shortcuts import render

from django.shortcuts import render, redirect

from django.contrib.auth import login, authenticate

from forms import SignUpForm
import TestProj.polls.migrations SignUpForm
import TestProj.core.forms

def signup(request):
    if request.method == 'POST':
       form = SignUpForm(request.POST)
        if form.is_valid():
         form.save()
            fname = form.cleaned_data.get('first_name')
            lname = form.cleaned_data.get('last_name')
            email = form.cleaned_data.get('email')
            pnumber = form.cleaned_data.get('phone_number')
            country = form.cleaned_data.get('country')
            c_city = form.cleaned_data.get('current_city')

            return redirect('home')
    else:
        form = SignUpForm()
    return render(request, 'sinup.html', {'form': form})

